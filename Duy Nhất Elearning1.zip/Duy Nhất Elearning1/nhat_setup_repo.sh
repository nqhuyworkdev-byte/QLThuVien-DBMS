#!/usr/bin/env bash
# Chạy trong thư mục library-db (đã giải nén từ library-db_skeleton.zip).
# Trước khi chạy: tạo repo TRỐNG tên library-db trên GitHub, rồi sửa USERNAME bên dưới.
set -e
USERNAME="<ten-tai-khoan-github>"

git init -b main
git add .
git commit -m "Khoi tao cau truc repo: sql, backup, docs, web, README, .gitignore"
git remote add origin "https://github.com/${USERNAME}/library-db.git"
git push -u origin main

# Tạo sẵn 5 nhánh theo quy ước
for b in huy binh hien hiep nhat; do
  git branch "$b"
  git push origin "$b"
done

# Nhánh của Nhất: commit đầu tiên để repo có dấu vết của bạn
git checkout nhat
echo "Nhat: moi truong cong tac, index, backup, kiem thu, tai lieu" > docs/nhat_phan_viec.txt
git add docs/nhat_phan_viec.txt
git commit -m "Them file mo ta phan viec cua Nhat"
git push origin nhat
echo "Xong. Moi 4 ban vao Settings > Collaborators, roi bao moi nguoi tu commit len nhanh cua minh."
